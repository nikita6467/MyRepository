import java.util.*;

public class Test8 {
	
	public static void main(String[] args) {
		
		String s="welcome to airtel";
		//emoclew ot letria // occurence of each char
		reverse(s);
		System.out.println("------------");
		count(s);
	}

	private static void reverse(String s) {
		// TODO Auto-generated method stub
		String str[]=s.split(" ");//welcome,to,airtel
		char ch[]=new char[str.length];
		String res="";
		for(String word:str)
		{
			//welcome
			ch=word.toCharArray();
			int start=0; int end=ch.length-1;
			while(start<end)
			{
				char temp=ch[start];
				ch[start]=ch[end];
				ch[end]=temp;
				start++;
				end--;
			}
			 res=res+String.valueOf(ch)+" ";
			
		}
		
		System.out.println(res);
		
		
	}

	private static void count(String s) {
		// TODO Auto-generated method stub
		Map<Character,Integer> map = new HashMap<>();
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(map.containsKey(c) && c!=' ')
			{
				int v=map.get(c);
				v=v+1;
				map.put(c, v);
			}
			else if(c!=' ')
			{
				map.put(c, 1);
			}
		}
		
		for(Map.Entry<Character, Integer> m : map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}
	}
	
	


}
