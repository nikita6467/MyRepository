import java.util.*;

public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="My name is Nikita Das";
		Map<Character,Integer> map = new HashMap<>();
		char ch[]=s.toCharArray();

		for(int i=0;i<ch.length;i++)
		{
			if(map.containsKey(ch[i]))
			{
				int v=map.get(ch[i]);
				v=v+1;
				map.put(ch[i], v);
			}
			else
			{
				map.put(ch[i], 1);
			}
		}

		for(Map.Entry<Character, Integer> m : map.entrySet())
		{
               System.out.println(m.getKey()+" "+m.getValue());
		}

	}

}
