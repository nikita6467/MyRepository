import java.util.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="uniphore welcome to uniphore";
		
		Map<String,Integer> map = new HashMap<>();
		String str[]=s.trim().split(" ");
		for(int i=0;i<str.length;i++)
		{
			if(map.containsKey(str[i]))
			{
				int v=map.get(str[i]);
				map.put(str[i], v+1);
			}
			else
			{
				map.put(str[i], 1);
			}
			
		}

		for(Map.Entry<String,Integer> m:map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}
	}
	
	

}
