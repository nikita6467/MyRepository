import java.util.Arrays;

public class test10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="N!K!T@Da$";
		char ch[]=s.toCharArray();
		int start=0; int end=ch.length-1;
		
		while(start<end)
		{
			if(!Character.isLetterOrDigit(ch[start]))
			{
				start++;
			}
			else if(!Character.isLetterOrDigit(ch[end]))
			{
				end--;
			}
			else
			{
				char temp=ch[start];
				ch[start]=ch[end];
				ch[end]=temp;
				
				start++;
				end--;
			}
		}
		
		String res=String.valueOf(ch)+"";
		System.out.println(res);

	}

}
