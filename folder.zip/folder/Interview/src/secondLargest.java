import java.util.*;

public class secondLargest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {2,4,5,8,9}; 
		System.out.println(secondMax(arr));
		System.out.println("------");
		int arr1[]= {2,2,2,2,2}; 
		System.out.println(secondMax(arr1));
		System.out.println("------");
		int arr2[]= {}; 
		System.out.println(secondMax(arr2));


	}

	private static int secondMax(int[] arr) {
		int max=Integer.MIN_VALUE;
		int secondMax=0;

		if(arr.length==0)
		{
			System.out.println("No second max");
			return -1;	
		}
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				int temp=max;
				max=arr[i];
				secondMax=temp;
			}
			else if(arr[i]>secondMax && arr[i]<max)
			{
				secondMax=arr[i];
			}
			
			else if(arr[i]==max && i==arr.length-1)
			{
				System.out.println("No second max");
				return -1;
			}
		}
		
		return secondMax;
	
	}

}
