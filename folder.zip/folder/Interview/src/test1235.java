import java.util.*;

public class test1235 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*String Str = “Anand”
				Result = {A=2, n=2, d=1}*/

		String str = "aaNjjggafFFAnand";
		char ch[]=str.toCharArray();
		Map<Character,Integer> map = new HashMap<>();
		for(int i=0;i<ch.length;i++)
		{			
			
				char lower=Character.toLowerCase(ch[i]); 
				char upper=Character.toUpperCase(ch[i]); 
				if(map.containsKey(lower))
				{
					int v=map.get(lower);
					map.put(lower, ++v); 
				}
				else if(map.containsKey(upper))
				{
					int v=map.get(upper);
					map.put(upper, ++v); 
				}
				else
				{
					map.put(ch[i], 1);
				}

		}
		
		for(Map.Entry<Character, Integer> m:map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}




	}

}
