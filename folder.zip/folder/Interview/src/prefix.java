import java.util.Arrays;
import java.util.*;

public class prefix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		int[] arr = {1,2,2,4,6,7,2,3,5,4,3,8,2,8};

		//o/p = 1,2,4,6,7,5,8

		Set<Integer> set = new HashSet<>();
		for(int i:arr)
		{
			//if(!set.contains(i))
			{
				set.add(i);
			}
		}
		
		System.out.println(set.toString());

	}
}
