import java.util.*;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/**input My name is Nikita Das
		output yM eamn si atikiN saD**/
		

		
		String s="My name is Nikita Das";
		String res=""; 
		
		String str[]=s.trim().split(" ");
		for(String word:str)
		{
			char ch[]=word.toCharArray();//m,y
			for(int i=0;i<ch.length-1;i++)
			{
				char temp=ch[i];
				ch[i]=ch[i+1];
				ch[i+1]=temp;
				//swapping characters
			}
			res=res+" "+String.valueOf(ch);
		}
		
		System.out.println(res);
		
		
	}

}
