import java.util.*;

public class test123 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {10,3,6,7,4,7,2,12,9,7};
		// Output = [[10],[3,6,7],[4,7],[2,12],[9],[7]]
		List<List<Integer>> outer=new ArrayList<>();
		List<Integer> inner= new ArrayList<>();
		int i=0; 
		for(i=0;i<arr.length-1;i++)
		{
			inner.add(arr[i]);
			if(arr[i]>arr[i+1])
			{
				outer.add(new ArrayList<>(inner));
				inner.clear();
			}
			
			if(!inner.isEmpty())
			{
				inner.add(arr[arr.length-1]);
				outer.add(new ArrayList<>(inner));
			}
		}
		System.out.println(outer.toString());
	}

}
