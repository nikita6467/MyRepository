
public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*pErSisTenT -- Input 
          PeRsIStENt -- Output*/

	}

}
