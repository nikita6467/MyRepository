
public class test1234 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Madamaaamadamaaaacdefgv";
		int count=0; int max=0; String res="";
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<=s.length();j++)
			{
				String substring = s.substring(i,j);//ma
				if(pallindromeCheck(substring)==true)
				{
					count++;
					int length=substring.length();
					max=Math.max(max, length);
					if(substring.length()==max)
					{
						res=substring;
					}
				}

			}
		}

		System.out.println(max);
		System.out.println(res);

	}

	private static boolean pallindromeCheck(String substring) {
		// TODO Auto-generated method stub
		int start=0; int end=substring.length()-1;
		while(start<end)
		{
			if(substring.charAt(start)!=substring.charAt(end))
			{
				return false;
			}
			start++;
			end--;
		}
		return true;
	}

}
