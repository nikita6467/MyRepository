import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestFileCreation{

	String baseDir="C:\\Users\\Arjun Das\\OneDrive\\Desktop\\nikita";
	FileManager fileManager;
	String filename="test";

	@BeforeClass
	private  void setup()
	{	
		fileManager=new FileManager(baseDir);
	}

	@Test
	public void testFileCreation() throws IOException
	{
		fileManager.createFile(filename, baseDir);
		File file = new File(baseDir, filename);
		boolean res=file.exists();
		Assert.assertTrue(res);
	}

	@Test
	public void testFileCreationNegative() 
	{
		try {
			String newbaseDir=baseDir+"\\12345";
			System.out.println(newbaseDir);
			fileManager.createFile(filename, newbaseDir);		
		}
		catch(Exception e)
		{

			Assert.assertFalse(false);
		}

	}


}
