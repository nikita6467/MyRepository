
public class vovelCons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		char ch[]=s.toLowerCase().toCharArray();
		int v=0;
		StringBuilder sb=new StringBuilder();

		for(char c:ch)
		{
			if(vowelCheck(c))
			{
				sb.append(c);
				++v;
			}
			else
			{
				
				if(v>=1)
				{
					int count=v;
					while(count>0)
					{
						sb.append(c);
						count--;
					}

				}
			}
			
		}
		
		System.out.println(sb.toString().toUpperCase());

	}

	private static boolean vowelCheck(char c) {
		// TODO Auto-generated method stub
		if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
		{
			return true;
		}
		return false;
	}

}
