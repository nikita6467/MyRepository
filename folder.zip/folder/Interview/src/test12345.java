import java.util.*
;

public class test12345 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="nnikittaa";
	/*	Map<Character,Integer> map = new HashMap<>();
		char ch[]=s.toCharArray();
		for(char c:ch)
		{
			if(map.containsKey(c))
			{
				int v=map.get(c);
				map.put(c, ++v);
			}
			else
			{
				map.put(c, 1);
			}
		}
		[2:44 PM] Anil Griddaluru (Guest)
    2n 1i 1k 1i 2t 1a

		for(Map.Entry<Character, Integer> m : map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}*/
		StringBuilder sb= new StringBuilder();
		char ch[]=s.toCharArray(); int count=1;
		for(int i=0;i<ch.length-1;i++)//nnikitta
		{
			if(ch[i]==ch[i+1])
			{
				count++;
				continue;
			}
			else
			{
				System.out.println(count+""+ch[i]);
				count=1;
			}
		}
		count=1;
		System.out.println(count+""+ch[ch.length-1]);

	}

}
