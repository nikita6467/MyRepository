import java.util.*;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="NikitaDas";
		Map<Character,Integer> map=new HashMap<>();
		
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(map.containsKey(ch))
			{
				int v=map.get(ch);
				v=v+1;
				map.put(ch, v);
			}
			else
			{
				map.put(ch, 1);
			}
		}
		
		for(Map.Entry<Character,Integer> m : map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}


	}

}
