import org.testng.annotations.Test;

public class TestFileCreationTest {

  @Test
  public void setupTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void testFileCreationTest() {
    throw new RuntimeException("Test not implemented");
  }
}
