
public class Test1 {
	
	public static void main(String[] args) {
		String s="abddba";
		int start=0;
		int end=s.length()-1;
		
		while(start<end)//breaking condition is start=end
		{
			if(s.charAt(start)==s.charAt(end))
			{
				
				start++;
				end--;
			}
			else
			{
				System.out.println(false);
				//return false;
				break;
			}
		}
		System.out.println(true);
	}

}
