import java.io.BufferedReader;

import java.io.BufferedWriter;

import java.io.File;

import java.io.FileReader;

import java.io.FileWriter;

import java.io.IOException;


public class FileManager {


	private String baseDir;



	public FileManager(String baseDir) {

		this.baseDir = baseDir;

	}



	public void createFile(String filename, String content) throws IOException {

		File file = new File(baseDir, filename);

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

			writer.write(content);

		}

	}



	public String readFile(String filename) throws IOException {

		File file = new File(baseDir, filename);

		StringBuilder content = new StringBuilder();

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

			String line;

			while ((line = reader.readLine()) != null) {

				content.append(line).append("\n");

			}

		}

		return content.toString();

	}



	public void updateFile(String filename, String newContent) throws IOException {

		File file = new File(baseDir, filename);

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

			writer.write(newContent);

		}

	}



	public void deleteFile(String filename) {

		File file = new File(baseDir, filename);

		if (file.exists()) {

			file.delete();

		}

	}

	public static void main(String[] args) {

		FileManager fileManager = new FileManager("C:\\Users\\Arjun Das\\OneDrive\\Desktop\\nikita");



		try {

			// Create a file

			fileManager.createFile("test.txt", "Hello, Java FileManager!");



			// Read and print the file content

			String content = fileManager.readFile("test.txt");

			System.out.println("File Content:\n" + content);



			// Update the file content

			fileManager.updateFile("test.txt", "Updated content");



			// Read and print the updated content

			content = fileManager.readFile("test.txt");

			System.out.println("Updated Content:\n" + content);



			// Delete the file

			fileManager.deleteFile("test.txt");



		} catch (IOException e) {

			e.printStackTrace();

		}

	}

}


