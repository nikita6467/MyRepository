import java.util.Arrays;

public class TestMock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="I am awesome";
		/*1. awesome am I

2. I ma emosewa*/
		changeposition(s);
		System.out.println("-----");
		changechars(s);

	}

	
	private static void changechars(String s) {
		// TODO Auto-generated method stub
		String str[]=s.split(" ");//welcome,to,airtel
		char ch[]=new char[str.length];
		String res="";
		for(String word:str)
		{
			//welcome
			ch=word.toCharArray();
			int start=0; int end=ch.length-1;
			while(start<end)
			{
				char temp=ch[start];
				ch[start]=ch[end];
				ch[end]=temp;
				start++;
				end--;
			}
			 res=res+String.valueOf(ch)+" ";
			
		}
		
		System.out.println(res);
	}


	private static void changeposition(String s) { //1.
		// TODO Auto-generated method stub
		String st[]=s.split(" "); 
		
		int start=0; int end=st.length-1;
		while(start<end)
		{
		      String temp=st[start];
		      st[start]=st[end];
		      st[end]=temp;
		      start++;
		      end--;
		}
	
		String result = String.join(" ", st);
		System.out.println(result);
	}


	
	

}
