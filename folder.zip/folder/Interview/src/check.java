import java.util.*;

public class check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Nikita";
		Map<Character,Integer> map=new HashMap<>();
		char ch[]=s.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			if(map.containsKey(ch[i]))
			{
				int v=map.get(ch[i]);
				map.put(ch[i], ++v);
			}
			else
			{
				map.put(ch[i],1);
			}
		}
		
		for(Map.Entry<Character, Integer> m : map.entrySet())
		{
			System.out.println(m.getKey()+":"+m.getValue());
		}
		

	}


}
