
public class restAssured {
//BASIC
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	// String endpoint="https://mapi.makemytrip.com/mobile-core-api-web/api/home/config/v1? 10.0&region=in&language=eng&currency=inr";

	check(60,60);
	System.out.println("-----------------");
	check(250,250);
	
	}

private static void check(Integer i, Integer j) {
	// TODO Auto-generated method stub
	
	if(i==j)
	{
		System.out.println(true);
	}
	else
	{
		System.out.println(false);
	}
	
	if(i.equals(j))
	{
		System.out.println(true);
	}
	else
	{
		System.out.println(false);
	}
}
}
