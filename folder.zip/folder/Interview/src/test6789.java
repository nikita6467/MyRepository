
public class test6789 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**I/P: ANNDEEEEEF, O/P : AN2DE5F
		I/P: AABDDA, O/P : A2BD2A
		I/P: TYUITI, O/P : TYUITI*/
		
		String s="ANNDEEEEEF";
		printcons(s);
	/*	String s1="AAABDDAA";
		printcons(s1);
		String s2="TYUITI";
		printcons(s2);*/

	}

	private static void printcons(String s) {
		// TODO Auto-generated method stub
		
		char ch[]=s.toCharArray();
		int i=0; int j=1; int count=1;
		String res="";
		
		while(j<ch.length)
		{
			
			if(ch[i]!=ch[j])
			{
				i=j;
				count=1;
				res=res+ch[i]+""; //a
				
				//i=1 
				j++;//j=2
			}
			else if(ch[i]==ch[j])
			{
				count++;
				res=res+ch[j]+count+"";//a2
				
				
				j=i+1;
				continue;
				
			}
		}
		res=res+ch[ch.length-1]+"";
		System.out.println(res);
		
	}

}
