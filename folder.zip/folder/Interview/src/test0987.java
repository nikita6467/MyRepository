
public class test0987 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="thequickbrownfoxjumpsoverthelazydog";

		//all 26 chars must exist once-true
		
		char ch[]=s.toCharArray();
		int start=0;
		char res[]=new char[26];
		int i=0;
		while(start<ch.length)
		{
			if(ch[start]=='a')
			{
				res[i]=ch[start];
				i++;
				start++;
			}
		}


	}

}
