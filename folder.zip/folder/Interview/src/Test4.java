import java.util.Arrays;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**[1,0,6,0,3,23,0,5,12]  --- Input
[0,0,0,1,6,3,23,5,12] -- Output**/
		
		int arr[]= {1,0,6,0,3,23,0,5,12};
		
		int res[]=new int[arr.length];
		int count=0;
		
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==0)
			{
				res[i]=0;
				count++;	
			}
		}
		int j=count;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]!=0)
			{
				res[j]=arr[i]; //res.add(arr[i]);
				j++;
			}
			
		}
		
		System.out.println(Arrays.toString(res));
		

	}

}
