import java.util.*;

public class tesr12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String words[] = {"auctioned", "actors", "altered", "streaming", "related",     
				"education", "aspired", "costar", "despair", "mastering"};

		HashMap<String,ArrayList<String>> map=new HashMap<>();
		List<List<String>> list=new ArrayList<>();

		for(String s:words)
		{
			char ch[]=s.toCharArray();//auctioned
			Arrays.sort(ch);//auctioned
			String charTurnedString=String.valueOf(ch);
			if(!map.containsKey(charTurnedString))
			{
				map.put(charTurnedString, new ArrayList<>());
			}

			map.get(charTurnedString).add(s);

		}

		list.addAll(map.values());

		System.out.println(list.toString());

	}

}
