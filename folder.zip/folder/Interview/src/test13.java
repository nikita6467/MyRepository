import java.util.Arrays;

public class test13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input ="Hello World Hi S^^^tart %%%Stop";
		//Output : olleH dlroW

		String str[]=input.split("\\s+");
		String res="";
		for(String word:str)//Hello,World
		{
			char ch[]=word.toCharArray();
			int start=0; int end=ch.length-1; //
			while(start<end)
			{
				char temp=ch[start];
				ch[start]=ch[end];
				ch[end]=temp;
				start++;
				end--;
			}
			res=res+String.valueOf(ch)+" ";

		}
		System.out.println(res);

	}

}
