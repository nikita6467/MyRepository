
public class stockbuyandsell {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int[] prices = {6,5,4,2,3,9};
				//Output: 6
		 int maxVal=prices[0]; //2
		 int minVal=prices[0]; //2 
		 
		 int res=0;
		 
		 for(int i=1;i<prices.length;i++)
		 {
			 if(prices[i]>maxVal)
			 {
				 maxVal=Math.max(maxVal, prices[i]);
				 if(i+1!=prices.length-1)
				 {
					 continue;
				 }
			 }
			 if(prices[i]<minVal)
			 {
				 if(i!=prices.length-1)
				 {
					 minVal=Math.min(minVal, prices[i]);
					
				 }
				 else
				 {
					 break;
				 }
				
			 }
		 }
		 res=maxVal-minVal;
		 System.out.println(res);
		 
		 
		
	}

}
