import java.util.*;

import org.testng.Assert;

public class test14 {

	 // static WebDriver driver;
    private String validEmail="login@codility.com";
    private String invalidEmail="unknown@codility.com";
    private String pass="password";
    String msg="";

    @Test
    public void testEmailAndPasswordFieldExist() {
        WebElement emailField=webDriver.findElement(By.id("email-input"));
         WebElement passField=webDriver.findElement(By.id("password-input"));
       Assert.assertNotNull(emailField);
       Assert.assertNotNull(passField);

    }
     @Test
    public void testValidCredentials() {
       login(validEmail,pass);
         msg=webDriver.findElement(By.xpath("//div[@id='container']/div")).getText();
       Assert.assertEquals("Welcome to Codility",msg);
   
    }

      @Test
    public void testInValidCreds() {
       login(invalidEmail,pass);
        msg=webDriver.findElement(By.xpath("//div[@id='container']/div")).getText();
       Assert.assertEquals("You shall not pass! Arr!",msg);
    }

          @Test
    public void testEmptyCreds() {
       login("","");
        msg=webDriver.findElement
       (By.xpath("//div[normalize-space()='Email is required']")).getText();
       Assert.assertEquals("Email is required",msg);
    }

        @Test
    public void testTabAndEnterKeys() {
 WebElement emailField=webDriver.findElement(By.id("email-input"));
         WebElement passField=webDriver.findElement(By.id("password-input"));
         emailField.sendKeys(validEmail);
         emailField.sendKeys(Keys.TAB);
         assertTrue(passField.equals(webDriver.switchTo().activeElement()));
         passField.sendKeys(pass);
         passField.sendKeys(Keys.ENTER);
         Assert.assertEquals("Welcome to Codility",msg);
    }

    public void login(String email,String password)
    {
 WebElement emailField=webDriver.findElement(By.id("email-input"));
         WebElement passField=webDriver.findElement(By.id("password-input"));
           emailField.sendKeys(email);
           passField.sendKeys(password);
           WebElement loginButton=webDriver.findElement(By.xpath("//button[@id='login-button']"));
           loginButton.click();

    }

}
