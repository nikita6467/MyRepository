
public class test9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int val[]= {1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0};
		int count=0; int max=0;
		for(int i=0;i<val.length-1;i++)
		{
			if(val[i]==0)
			{
				if(val[i]==val[i+1])
				{
					count++;
					max=Math.max(max, count);
				}
				else
				{
				
					System.out.println(count);
					count=1;
				}
			}
		}
		System.out.println("MAX"+max);
	}

}
