package basic;
import static io.restassured.RestAssured.*;


public class basic {
	
	public static void main(String[] args) {
		RestAssured
	}

}
