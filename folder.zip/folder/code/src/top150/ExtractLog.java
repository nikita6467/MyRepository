package top150;

import java.util.ArrayList;
import java.util.List;

public class ExtractLog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 List<List<String>> logData = new ArrayList<>();
		 List<List<String>> resData = new ArrayList<>();
		 List<String> res=new ArrayList<>();

	        // Simulated log file data
	        String[][] logs = {
	                {"error", "Failed to connect to server", "2024-01-10 08:15:23"},
	                {"debug", "Processing data", "2024-01-10 08:16:12"},
	                {"critical", "System crashed unexpectedly", "2024-01-10 08:17:45"},
	                {"error", "Invalid input received", "2024-01-10 08:18:30"},
	                {"debug", "Initializing application", "2024-01-10 08:19:02"},
	                {"error", "Database connection failed", "2024-01-10 08:20:55"},
	                {"status", "Server is running", "2024-01-10 08:21:40"},
	                {"debug", "Executing query", "2024-01-10 08:22:13"},
	                {"critical", "Memory allocation error", "2024-01-10 08:23:09"},
	                {"error", "File not found", "2024-01-10 08:24:58"}
	        };
	        // Populating the list with log data
	        for (String[] log : logs) {
	            List<String> logRow = new ArrayList<>();
	            logRow.add(log[0]); // Status
	            logRow.add(log[1]); // Failed Message
	            logRow.add(log[2]); // Date and Time
	            logData.add(logRow);
	        }
	        
	        for(List<String> list : logData)
	        {
	        	for(int i=0;i<list.size();i++)
	        	{
	        		if(list.get(0).contains("error") || list.get(0).contains("critical"))
		        	{
		        		res.add(list.get(i));
		        	}
	        	}
	        	
	        }
	        
	        resData.add(res);
	        
	        System.out.println(resData.toString());

	}

}
