package top150;

public class BestTimeToBuyAndSellStock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {7,1,5,3,6,4};
		int res=0;
		int max=Integer.MIN_VALUE;

		int minP= arr[0];
		for(int i=0;i<arr.length;i++)
		{
			minP=Math.min(minP, arr[i]);
			max=Math.max(max, arr[i]-minP);

		}
		
		System.out.println(max);

	}
}
