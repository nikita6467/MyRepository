package top150;

public class RemoveElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//https://leetcode.com/problems/remove-element/description/?envType=study-plan-v2&envId=top-interview-150
	}

}
