package top150;

import java.util.Arrays;

public class LongestConsecutiveSequenceNumArray {
//https://leetcode.com/problems/longest-consecutive-sequence/description/?envType=study-plan-v2&envId=top-interview-150
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nums = {1,2,0,1};
		Arrays.sort(nums);
		int res=Integer.MIN_VALUE; int count=1;
		for(int i=0;i<nums.length-1;i++)
		{
			if(nums[i+1]-nums[i]==1)
			{
				count++;
				res=Math.max(res, count);
			}
			else if(nums[i]==nums[i+1])
			{
				continue;
			}
			else
			{
				count=1;
			}
		}
		res=Math.max(res,count);
		if(nums.length==0 || res==Integer.MIN_VALUE)
		{
			System.out.println(0);
		}
		else
		{
			System.out.println(res);
		}
		
		
		
	}

}
