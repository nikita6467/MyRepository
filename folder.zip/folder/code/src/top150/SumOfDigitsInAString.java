package top150;

public class SumOfDigitsInAString {
	
	public static void main(String[] args) {
		String s="123!python!@456*";
		int sum=0;
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			
			int v=c-'0';
			if(v>0 && v<9)
			{
				System.out.println(v);
				sum=sum+v;
			}
		}
		
		System.out.println(sum);
	}

}
