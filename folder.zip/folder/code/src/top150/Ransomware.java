package top150;

import java.util.*;

public class Ransomware {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String ransomNote = "aa", magazine = "aab";
		Map<Character, Integer> map = new HashMap<>();
		String s1=ransomNote;
		String s2=magazine;

		for(int i=0;i<s2.length();i++)
		{
			char c=s2.charAt(i);
			if(map.containsKey(c))
			{
				int v=map.get(c);
				map.put(c,v+1);
			}
			else
			{
				map.put(c,1);
			}
		}

		for(int i=0;i<s1.length();i++)
		{
			char d=s1.charAt(i);
			if(map.containsKey(d)&&map.get(d)>0)
			{
				int v=map.get(d);
				map.put(d,v-1);
			}
			else
			{
				System.out.println(false);
			}

		}
		System.out.println(true);	}
}


