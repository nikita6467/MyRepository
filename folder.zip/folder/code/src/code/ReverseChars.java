package code;

import java.util.Arrays;

public class ReverseChars {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="abcde";
		//out:badce
		char ch[]=s.toCharArray();

		int i=0;int j=1;
		if(ch.length%2!=0)
		{
			while(j<=ch.length-2&&i<j)
			{
				char t=ch[i];
				ch[i]=ch[j];
				ch[j]=t;
				j=j+2;
				i=i+2;
			}
		}
		if(ch.length%2==0)

		{
			while(j<=ch.length-1&&i<j)
			{
				char t=ch[i];
				ch[i]=ch[j];
				ch[j]=t;
				j=j+2;
				i=i+2;
			}
		}
		String string = new String(ch); 
		System.out.println(string);

	}

}
