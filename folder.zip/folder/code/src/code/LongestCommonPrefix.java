package code;

import java.util.*;

public class LongestCommonPrefix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String []strs = {"flower","flow","flight"};
		Arrays.sort(strs);
		StringBuilder sb = new  StringBuilder();
		System.out.println(Arrays.toString(strs));
		
		int i=0;
		{
			while(i<strs[0].length()&& strs[0].charAt(i)==strs[strs.length-1].charAt(i))
			{
				sb.append(strs[0].charAt(i));
			}
		}
		System.out.println(sb);

	}

}
