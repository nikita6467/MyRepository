package code;

public class CompressionOfCharactersInaString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="aabcccd"; //a2bc3d
		StringBuilder sb=new StringBuilder();
		int count=0;

		for(int i=0;i<s.length();i++)
		{
			count++;
			if (i + 1 >= s.length() || s.charAt(i) != s.charAt(i + 1)) {
				sb.append(s.charAt(i));
				if(count>1)
				{

					sb.append(count);

				}
				count = 0;
			}
		}

		
		System.out.println(sb.toString());

	}

}
