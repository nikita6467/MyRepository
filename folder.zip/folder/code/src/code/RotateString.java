package code;

public class RotateString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "abcde", goal = "cdea"; String res="";
		
		res=s+s;
		System.out.println(res);
		if(res.contains(goal))
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		
	
	}

}
