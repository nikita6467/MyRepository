package code;

public class ReverseVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "hello";

		int start=0;
		int end=s.length()-1;
		char[] ch=s.toCharArray();

		while(start<end)
		{
			if(ch[start]=='a'||ch[start]=='e'||ch[start]=='i'
					||ch[start]=='o'||ch[start]=='u')
			{
				if(ch[end]=='a'||ch[end]=='e'||ch[end]=='i'
						||ch[end]=='o'||ch[end]=='u')
				{
					char temp=ch[start];
					ch[start]=ch[end];
					ch[end]=temp;
					start++;
					end++;

				}
			}
			else
			{
				start++;

			}
		}
		String str=new String(ch);
		System.out.println(str);

	}

}


