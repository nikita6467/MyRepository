package code;

import java.util.*;

public class LongestPallindromicSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Iamatechcaracerorpreec";
		 Map<Character,Integer> map = new HashMap<>();
		 String res="";
		 
		 
		 for(int i=0;i<s.length();i++)
		 {
			 if(!map.containsKey(s.charAt(i)))
			 {
				map.put(s.charAt(i), i); 
			 }
			 else
			 {
				 res=s.substring(map.get(s.charAt(i)),i+1);
				 
			 }
		 }
		 System.out.println(res);
		 
	}

}
