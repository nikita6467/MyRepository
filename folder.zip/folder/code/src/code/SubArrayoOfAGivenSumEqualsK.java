package code;

import java.util.*;

public class SubArrayoOfAGivenSumEqualsK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {1, 7, 3, 9}; int k = 10;
		Map<Integer,Integer> map=new HashMap<>();
		int count=0; int sum=0;
		map.put(0, 1);
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
			if(map.containsKey(sum-k))
			{
				count=count+map.get(sum-k);//count=count+1;
			}
			map.put(sum, map.getOrDefault(sum, 0)+1);
		}
		System.out.println(count);



	}

}
