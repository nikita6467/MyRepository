package code;

import java.util.*;

public class CountDistinctElementsInWindowOfSizeK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {1,2,2,1,3,1,1,3}; int k=4;int count=1;
		Map<Integer,Integer> map=new HashMap<>();
		List<Integer> list=new ArrayList<>();
		int start=0; int end=0;
		
		  while (end < arr.length) {
	            map.put(arr[end], map.getOrDefault(arr[end], 0) + 1);

	            if (end - start + 1 == k) {
	                System.out.println(map.size());

	                // Slide the window
	                if (map.get(arr[start]) == 1) {
	                    map.remove(arr[start]);
	                } else {
	                    map.put(arr[start], map.get(arr[start]) - 1);
	                }

	                start++;
	            }

	            end++;
	        }


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
