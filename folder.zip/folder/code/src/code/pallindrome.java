package code;

public class pallindrome {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		String s="a man, a plan, a canal, panama";
		String s1="madamnitin";
		//System.out.println(check(s));
		System.out.println(countSubstrings(s1));

	}

	public static int countSubstrings(String s) {
        int count = 0;
        int n = s.length();

        // Loop through all possible substrings
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j <= n; j++) {
                // Check if the substring is a palindrome
                if (isPalindrome(s.substring(i, j))) {
                    count++;
                }
            }
        }

        return count;
    }

    // Function to check if a string is palindrome
    public static boolean isPalindrome(String s) {
        int left = 0;
        int right = s.length() - 1;

        while (left < right) {
            if (s.charAt(left) != s.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }

	private static boolean check(String s) {
		// TODO Auto-generated method stub

		int start=0;
		int end=s.length()-1;

		while(start<end)
		{
			if(!Character.isLetterOrDigit(s.charAt(start)))
			{
				start++;
			}
			else if(!Character.isLetterOrDigit(s.charAt(end)))
			{
				end--;
			}
			else if(s.charAt(start)!=s.charAt(end))
			{

				return false;

			}
			else
			{
				start++;
				end--;
			}

		}

		return true;
	}

}
