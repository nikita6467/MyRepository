package code;

import java.util.*;

public class RomanToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Map<Character,Integer> map = new HashMap<>();
        map.put('I',1);
        map.put('V',5);
        map.put('X',10);
        map.put('L',50);
        map.put('C',100);
        map.put('D',500);
        map.put('M',1000);
        String s="MCMXCIV";
        
        int sum=0; 
        char curr=s.charAt(0);
        char prev;
        sum=sum+map.get(curr);
        
        for(int i=1;i<s.length();i++)
        {
        	curr=s.charAt(i);
        	prev=s.charAt(i-1);
        	
        	int a=map.get(curr);
        	int b=map.get(prev);
        	
        	if(a>b)
        	{
        		sum=sum-b+(a-b);
        	}
        	else
        	{
        		sum=sum+a;
        	}
        }
        System.out.println(sum);

	}

}
