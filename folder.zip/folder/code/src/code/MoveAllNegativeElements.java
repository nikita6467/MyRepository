package code;

import java.util.Arrays;

public class MoveAllNegativeElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {1, -1, 3, 2, -7, -5, 11, 6 };
		int res[]=new int[arr.length]; int start=0; int end=arr.length-1;
		

		for(int i=0;i<arr.length;i++)
		{
			while(start<end)
			{
				if(arr[i]<0)
				{
					res[end]=arr[i];
					end--;
				} 
				else if(arr[i]>0)
				{
					res[start]=arr[i];
					start++;
				}
				break;
			}
		}

		System.out.println(Arrays.toString(res));

	}

}
