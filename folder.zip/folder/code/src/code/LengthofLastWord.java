package code;

public class LengthofLastWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Hello World";
		  String str[]=s.split(" ");
	       int s1=str[str.length-1].length();
	       System.out.println(s1);
	       
	}

}
