package code;

import java.util.HashSet;
import java.util.Set;

public class LongestSubstringWithoutRepeatingCharacters {
	//https://leetcode.com/problems/longest-substring-without-repeating-characters/submissions/1102511526/?envType=study-plan-v2&envId=top-interview-150
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s ="abcabcbb";
		int start=0;
		int end =0;
		int max=0;
		Set<Character> set=new HashSet<>();
		char ch[]=s.toCharArray();

		while(end<ch.length)
		{
			if(!set.contains(ch[end]))
			{
				set.add(ch[end]);
				max=Math.max(max, set.size());
				end++;
			}
			else
			{
				set.remove(ch[start]);
				start++;
				end++;
			}
		}
		System.out.println(max);
			
	

	}

}
