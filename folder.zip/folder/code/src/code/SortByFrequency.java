package code;

import java.util.*;

public class SortByFrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//2 parts -  hashmap and priorityQueue

		String s="tree";
		Map<Character,Integer> map = new HashMap<>();
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			map.put(c, map.getOrDefault(c,0)+1);
		}

		PriorityQueue<Map.Entry<Character, Integer>> pq=new PriorityQueue<>
		((a,b)->b.getValue()-a.getValue());//max heap

		for(Map.Entry<Character, Integer> m:map.entrySet())
		{
			pq.offer(m); // stored in pairs
		}
		while(!pq.isEmpty())
		{
			Map.Entry<Character, Integer> m = pq.poll();
			for(int i=0;i<m.getValue();i++)
			{
				sb.append(m.getKey());
			}
		}

		System.out.println(sb.toString());

	}

}
