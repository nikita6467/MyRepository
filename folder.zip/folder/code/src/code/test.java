package code;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c='1';
		
		int s=c-'0';
		System.out.println(s);

	}

}
