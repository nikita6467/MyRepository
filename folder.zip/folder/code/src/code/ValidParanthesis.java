package code;

import java.util.*;

public class ValidParanthesis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//https://leetcode.com/problems/valid-parentheses/submissions/935313306/
		String s="()";

		Stack<Character> st = new Stack<>();
		Map<Character,Character> map = new HashMap<>();

		map.put('(',')');
		map.put('{','}');
		map.put('[',']');
		char ch[]=s.toCharArray();

		for(int i=0;i<ch.length;i++)
		{

			if(st.isEmpty())
			{
				st.push(ch[i]);
				continue;
			}
			if(!st.isEmpty())
			{
				if(ch[i]==')' || ch[i]=='}' || ch[i]==']')
				{
					st.pop();
				}
			}
			else
			{
				st.push(ch[i]);
			}
		}

		if(st.isEmpty())
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
	}

}
