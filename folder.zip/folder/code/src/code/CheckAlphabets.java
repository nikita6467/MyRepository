package code;

import java.util.*;

public class CheckAlphabets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "thequickbrownfoxjumpsoverthelazydog";
		withCollection(s);
		System.out.println();
		withoutCollection(s);

	}

	private static void withoutCollection(String s) {
		// TODO Auto-generated method stub
		int count=0;
		Set<Character> set=new LinkedHashSet<>();
		for(char c:s.toCharArray())
		{
			if(!set.contains(c))
			{
				set.add(c);
				count++;
			}
		}

		System.out.println(count);
		System.out.println(set.size());

	}

	private static void withCollection(String s) {
		// TODO Auto-generated method stub
		boolean arr[]=new boolean[26];
		int count=0;

		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(c>='a' && c<='z')
			{
				int index=c-'a';
				if(!arr[index])
				{
					arr[index]=true;
					count++;
				}
			}
		}
		if(count==26)
		{
			System.out.println("true");
		}
	}

}
