package code;

import java.util.Stack;

public class RemoveOuterParanthesis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Character> st = new Stack<>();
		String res="";
		String s="((()))";
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(st.isEmpty() && c=='(')
			{
				st.push(c);
				continue;
				
			}
			else if(st.size()==1&&c==')')
			{
				st.pop();
				continue;
			}
			if(c=='(')
			{
				st.push(c);
			}
			if(c==')')
			{
				st.pop();
			}
			
			res=res+c+" ";		
			}
		
		System.out.println(res);
		

	}

}
