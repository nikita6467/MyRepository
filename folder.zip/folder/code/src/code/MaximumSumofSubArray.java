package code;

public class MaximumSumofSubArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]= {1,-3,2,3,-4};
		int maxSum=0;
		int start=0; int end=0; 
		int sum=0;

		while(end<arr.length)
		{
			sum=sum+arr[end];
			maxSum=Math.max(maxSum, sum);
			end++;

			while(sum<0)
			{
				sum=sum-arr[start];
				start++;
				//slide
			}
		}

		System.out.println(maxSum);
	}

}
