package Arrays;

public class SingleTonCLass {

	/*Can have only 1 object at a time
	 * Design:
	 * make a private cons
	 * public static method with a return type of the instance of this class*/

	//obj of the class initialization
	private static SingleTonCLass singleton=null;
	public String str;

	private SingleTonCLass()
	{
		str="Hi";
	}

	//method of this class 's type which will return obj
	public static SingleTonCLass getInstance()
	{
		if(singleton==null)
		{
			singleton=new SingleTonCLass(); // create obj only once
		}
		return singleton;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SingleTonCLass x = SingleTonCLass.getInstance();
		SingleTonCLass y = SingleTonCLass.getInstance();

		x.str=y.str.toUpperCase();
		System.out.println(y.str);
	}

}
