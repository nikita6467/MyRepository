package Arrays;

import java.util.Arrays;

public class MergeSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []nums1 = {1,2,3,0,0,0};
		int m = 3;
		int []nums2 = {2,5,6};
		int n = 3;
		
		int i=m-1; int j=n-1; int k=m+n-1;
		while(j>=0)
		{
			if(j>=0&&nums1[i]>nums2[j])
			{
				nums1[k]=nums1[i];
				k--;
				i--;
			}
			else
			{
				nums1[k]=nums2[j];
				k--;
				j--;
			}
			
		}
		
		System.out.println(Arrays.toString(nums1));
		

	}

}
