package Arrays;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertThrows;

import org.testng.annotations.Test;

/**
 * contains unit tests using TestNG framework 
 * to verify the correctness of the findLastPersonPosition method.
 * @author Nikita Das
 * @date 28-11-2023
 * 
 * */
public class Nikita_programTest {

/* Test cases cover various scenarios including edge cases like 1 person, negative input, 
 * and larger input sizes to ensure the method handles different cases correctly.*/
	
	@Test
    public void testFindLastPersonPosition() {
        // Test for various input sizes
        assertEquals(1, Nikita_program.findLastPersonPosition(1));
        assertEquals(1, Nikita_program.findLastPersonPosition(2));
        assertEquals(3, Nikita_program.findLastPersonPosition(3));
        assertEquals(3, Nikita_program.findLastPersonPosition(5));
        assertEquals(5, Nikita_program.findLastPersonPosition(10));
        assertEquals(73, Nikita_program.findLastPersonPosition(100));   
        assertEquals(1753, Nikita_program.findLastPersonPosition(1900));   
        
	}

    @Test
    public void testInvalidInput() {
        // Test for negative input
        assertThrows(IllegalArgumentException.class, () -> Nikita_program.findLastPersonPosition(-5));

        // Test for zero input
        assertThrows(IllegalArgumentException.class, () -> Nikita_program.findLastPersonPosition(0));
}
}