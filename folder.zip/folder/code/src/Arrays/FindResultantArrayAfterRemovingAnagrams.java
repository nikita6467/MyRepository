   package Arrays;

import java.util.*;

public class FindResultantArrayAfterRemovingAnagrams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String []words = {"abba","baba","bbaa","cd","cd"};

		List<String> res= new ArrayList<>();

		Set<String> set=new HashSet<>();
		
		for (String word: words) {
			char[] charArray = word.toCharArray();
			Arrays.sort(charArray);
			String sortedWord = String.valueOf(charArray);

		if(!set.contains(sortedWord))
		{
			set.add(sortedWord);
		}
		}
		res.addAll(set);

		System.out.println(res);
	}

}
