package Arrays;

import java.util.*;

public class SummaryRanges {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int nums[] = {0,2,3,4,6,8,9};

	      ArrayList<String> ans = new ArrayList<String>();
	        int i=0,j=0;
	        final int n = nums.length;
	        
	        while(i<n){
	            j=i;
	            while(j+1<n && (long)nums[j+1]-nums[j] == 1){
	                j++;
	            }
	            
	            if(i==j){
	                ans.add(String.valueOf(nums[i]));
	                i++;
	            }
	            else{
	                ans.add(String.valueOf(nums[i])+"->"+String.valueOf(nums[j]));
	                j++;
	                i=j;
	            }
	        }
	        
	        System.out.println(ans.toString());
	}

}
