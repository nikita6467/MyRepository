  package Arrays;

public class FactorialTrailingZeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=13;
		int ans=getCount(n);
		System.out.println(ans);
	}

	public static int fact(int n)
	{
		if(n==0)
		{
			return 1;
		}
		else
		{
			return (n*fact(n-1));
		}
	}

	public static int getCount(int n)
	{

		int factorial=fact(n);
		int count=0; 
		while(factorial>0)
		{
			if(factorial%10==0)
			{
				count++;
				int temp=factorial/10;
				factorial=temp;
				continue;
			}
			else
			{
				String v=Integer.toString(factorial);
				char []ch=v.toCharArray();
				for(int i=0;i<ch.length;i++)
				{
					if(ch[i]=='0')
					{
						count++;
						if(i==ch.length-1)
						{
							break;
						}
					}
				}
			}
		}



		return count;
	}

}

