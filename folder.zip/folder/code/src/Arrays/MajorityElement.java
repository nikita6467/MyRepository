 package Arrays;

import java.util.HashMap;
import java.util.Map;

public class MajorityElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int []nums = {3,3,4};
		 Map<Integer,Integer> map = new HashMap<>();
	     for(int i=0;i<nums.length;i++)
	     {
	         if(map.containsKey(nums[i]))
	         {
	        	  int v=map.get(nums[i]);
		            map.put(nums[i],v+1);
	         }
	         else {
	        	 map.put(nums[i], 1);
	         }
	       
	     } 
	     int ans=0;int max=0;
	    for(Map.Entry<Integer,Integer> m : map.entrySet())
	    {
	       
	        int v=m.getValue();
	        if(v>max)
	        {
	        	max=v;
	        	ans=m.getKey();
	        }
	        
	  
	        
	    }
	    System.out.println(ans);
	}

}
