package Arrays;

import java.util.Scanner;

public class Nikita_program {


	/**
	 * This method implements the algorithm to determine the last person's position 
	 * based on the given problem description.
	 *
	 * @param totalPeople total number of people in the line
	 * @return position of the last person standing
	 * @author Nikita Das
	 * @date 28-11-2023
	 */
	public static int findLastPersonPosition(int totalPeople) {
		if (totalPeople <= 0) {
			throw new IllegalArgumentException("Total number of people must be greater than 0.");
		}

		// Finds the highest power of 2 less than or equal to totalPeople
		int highestPowerOfTwo = 1;
		while (highestPowerOfTwo <= totalPeople) {
			//We will solve the problem for the powers of 2, n=2,4,16,32,64,128,...
			highestPowerOfTwo *= 2;
		}
		highestPowerOfTwo /= 2;

		// Calculates the last person's position based on the formula

		/*The solution requires getting the nearest number that is the power of 2 
		 * which is smaller than total number of people
		 * Formula applied - 
		 * Consider X persons, and Y is the highest power of 2 less than or equal to Y.
		 * (X - Y) + 1 is the surviving person.*/

		return 2 * (totalPeople - highestPowerOfTwo) + 1;
	}

	/** 
	 * Use the function to find the last person's position 
	 * for a line of 100 people and prints the result.*/
	public static void main(String[] args) {
		
		int totalPeople = 100;
		int lastPersonPosition = findLastPersonPosition(totalPeople);
		System.out.println("The position to stay in to be the last person standing: " + lastPersonPosition);
	}
}
