package Arrays;

import java.util.*;

public class groupAnagram {
	public static void main(String[] args) {

		String []strs = {"eat","tea","tan","ate","nat","bat"};
	 	HashMap<String,List<String>> map=new HashMap<>();

		List<List<String>> result = new ArrayList<>();


		for (String word: strs) {
			char[] charArray = word.toCharArray();


			Arrays.sort(charArray);

			String sortedWord = String.valueOf(charArray);

			if (!map.containsKey(sortedWord)) { //sortedword=aet
				map.put(sortedWord, new ArrayList<>());
			}

			

			map.get(sortedWord).add(word);


		}
		result.addAll(map.values());

		System.out.println(result);
	}

}
