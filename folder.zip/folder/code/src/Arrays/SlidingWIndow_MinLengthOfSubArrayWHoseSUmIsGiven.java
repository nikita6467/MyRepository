  package Arrays;

public class SlidingWIndow_MinLengthOfSubArrayWHoseSUmIsGiven {

	public static void main(String[] args) {

		/*Given an array of positive integers nums and a positive integer target, 
		 * return the minimal length of a 
subarray
 whose sum is greater than or equal to target. 
 If there is no such subarray, return 0 instead.*/
		int start=0;
		int end=0;
		int sum=0;
		int min=Integer.MAX_VALUE;
		int target = 7;
		int[] nums = {2,3,1,2,4,3};

		while(end<nums.length)
		{
			sum=sum+nums[end];

			while(target<=sum)//when k is given and we need sum then end-start+1<=k . Here sum is given we need k
			{
				min=Math.min(min,end-start+1);
				sum=sum-nums[start];//slide
				start++;   
			}
			end++;
		}

		if(min!=Integer.MAX_VALUE)
		{
			System.out.println(min);
		}
		else
		{
			System.out.println(0);
		}

	}

}
